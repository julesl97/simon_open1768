#include "lpc17xx_pinsel.h"
#include "global.h"


void pin_Configuration(void)
{
  // d�claration des structures de configuration
	PINSEL_CFG_Type maconfig;
	PINSEL_CFG_Type maconfig2;
	
	// configuration des GPIOs
	// directement dans les registres
	//LPC_GPIO0->FIODIR &= ~(1<<0); 
	//LPC_GPIO0 ->FIOMASK = ~(1<<0); 
	// en utilisant une fonction 
	GPIO_SetDir(0,(1<<19),0);
	
	// configuration des pinsel
	maconfig.Portnum = PINSEL_PORT_0;
	maconfig.Pinnum =PINSEL_PIN_19;
	maconfig.Funcnum = PINSEL_FUNC_0;
	maconfig.Pinmode =PINSEL_PINMODE_PULLUP;
	maconfig.OpenDrain = PINSEL_PINMODE_NORMAL;
  PINSEL_ConfigPin(&maconfig);
	
	
	// configuration des GPIOs
	// directement dans les registres
	//LPC_GPIO1->FIODIR &= ~(1<<9); 
	//LPC_GPIO1 ->FIOMASK = ~(1<<9); 
	// en utilisant une fonction 
	GPIO_SetDir(1,1<<9,1);
	
	// configuration des pinsel
	maconfig2.Portnum = PINSEL_PORT_1;
	maconfig2.Pinnum =PINSEL_PIN_9;
	maconfig2.Funcnum = PINSEL_FUNC_0;
	maconfig2.Pinmode =PINSEL_PINMODE_PULLDOWN;
	maconfig2.OpenDrain = PINSEL_PINMODE_NORMAL;
  PINSEL_ConfigPin(&maconfig2);
	
}

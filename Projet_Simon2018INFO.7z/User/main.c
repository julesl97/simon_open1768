//===========================================================//
// Projet Micro - INFO1 - ENSSAT - S2 2018							 //
//===========================================================//
// File                : Programme de d�part
// Hardware Environment: Open1768	
// Build Environment   : Keil �Vision
//===========================================================//

#include "lpc17xx_libcfg_default.h"
#include "touch\ili_lcd_general.h"
#include "touch\lcd_api.h"
#include "affichagelcd.h"
#include "touch\touch_panel.h"


#include "globaldec.h" // fichier contenant toutes les d�clarations de variables globales
#include "global.h"
#include <stdio.h>
#include <stdlib.h>

void pin_Configuration(void);
void T1_Init(void);
void T0_Init(void);
void JouerNote(int dureeEnUs, int numero_note);
int getNumeroNote();


//===========================================================//
// Function: Main
//===========================================================//
int main(void){	  
	uint32_t score=0;
	uint8_t sequence[256];
	int i;
	
	lcd_Initializtion(); // init pinsel ecran et init LCD
	
	touch_init(); // init pinsel tactile et init tactile 
	pin_Configuration();
	NVIC_EnableIRQ(TIMER1_IRQn);
	NVIC_EnableIRQ(TIMER0_IRQn);
	T1_Init();
	T0_Init();

	// Init(); // init variable globales et pinsel son et IR
	// affichage de l'�cran maitre

	sprintf(chaine,"Entrez une sequence      ");
	LCD_write_english_string(32,30,chaine,White,Blue);
	dessiner_rect(10,60,110,110,2,1,Black,Yellow);
	dessiner_rect(120,60,110,110,2,1,Black,Green);
	dessiner_rect(10,170,110,110,2,1,Black,Blue);
	dessiner_rect(120,170,110,110,2,1,Black,Red);

	init_i2c_eeprom();
	
	score=0;
	mode = START|JOUER_SEQUENCE;
	sequence[0]=rand()%4;
	i=0;  //avancement sequence
	
	while(1){
		if((mode&CLAVIER_JEU) != 0){
			touch_read();
			if(!estAppuye){
				int note=getNumeroNote();
				if(note<4){
					JouerNote(200000, note);
					attentems(200);
					if(sequence[i]==note){
						i++;
						if(i==score+1 && score!=255){
							score++;
							sequence[score]=rand()%4;
							i=0;
							JouerNote(500000, NOTE_AIGUE);
							attentems(1000);
							mode |= JOUER_SEQUENCE;
						}
					}else{
						JouerNote(500000, NOTE_GRAVE);
						attentems(1500);
						score=0;
						i=0;
						sequence[0]=rand()%4;
						mode |= JOUER_SEQUENCE;
					}
				}
			}
			mode &= ~CLAVIER_JEU;
			estAppuye=TRUE;
		}
		if((mode&JOUER_SEQUENCE) != 0){
			JouerNote(200000, sequence[0]);
			for(i=1; i<score+1; i++){
				attentems(300);
				JouerNote(200000, sequence[i]);
			}
			i=0;
			mode &= ~JOUER_SEQUENCE;
		}
		if((mode&WRITE_DATA_EEPROM) != 0){}
		if((mode&READ_DATA_EEPROM) != 0){}
		
	}			
	
	
}


//---------------------------------------------------------------------------------------------	
#ifdef  DEBUG
void check_failed(uint8_t *file, uint32_t line) {while(1);}
#endif

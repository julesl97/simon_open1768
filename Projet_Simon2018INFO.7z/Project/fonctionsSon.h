
void T0_Init(void);
void JouerNote(int dureeEnUs, int numero_note);